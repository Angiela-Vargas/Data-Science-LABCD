# LABCD > 2025-05-01 6:17pm
https://universe.roboflow.com/labcd/labcd

Provided by a Roboflow user
License: CC BY 4.0

